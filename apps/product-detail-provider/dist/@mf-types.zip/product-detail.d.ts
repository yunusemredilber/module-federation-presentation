export * from './compiled-types/components/product-detail/index';
export { default } from './compiled-types/components/product-detail/index';