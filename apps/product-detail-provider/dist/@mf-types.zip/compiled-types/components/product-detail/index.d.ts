import './style.scss';
declare function ProductDetail(): import("react/jsx-runtime").JSX.Element;
export default ProductDetail;
