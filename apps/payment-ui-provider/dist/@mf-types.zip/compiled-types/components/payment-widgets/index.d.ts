import './style.scss';
declare function PaymentWidgets(): import("react/jsx-runtime").JSX.Element;
export default PaymentWidgets;
