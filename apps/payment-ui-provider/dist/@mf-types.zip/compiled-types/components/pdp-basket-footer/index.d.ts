import './style.scss';
declare function PdpBasketFooter(): import("react/jsx-runtime").JSX.Element;
export default PdpBasketFooter;
