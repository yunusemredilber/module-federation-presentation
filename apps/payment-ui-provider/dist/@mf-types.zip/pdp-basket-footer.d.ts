export * from './compiled-types/components/pdp-basket-footer/index';
export { default } from './compiled-types/components/pdp-basket-footer/index';