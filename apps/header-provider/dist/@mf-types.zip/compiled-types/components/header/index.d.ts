import './style.scss';
interface HeaderProps {
    disableFavorites?: boolean;
}
declare function Index({ disableFavorites }: HeaderProps): import("react/jsx-runtime").JSX.Element;
export default Index;
